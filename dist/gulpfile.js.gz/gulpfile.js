var gulp = require('gulp');
const tar = require('gulp-tar');
var gzip = require('gulp-gzip');

gulp.task('default', () =>
gulp.src('*')
    .pipe(gzip())
    .pipe(gulp.dest('dist'))
);