module.exports = { 
    apps: [{
      name    : "node-app",
      script  : "npm",
      args    : "start"
    }]
  }