var gulp = require('gulp');
const tar = require('gulp-tar');
var gzip = require('gulp-gzip');

gulp.task('default', () =>
gulp.src('*')
    .pipe(tar('build.tar'))
    .pipe(gzip())
    .pipe(gulp.dest('dist'))
);